import kareltherobot.*;

public class LetterH implements RobotTask
{
    /*
     * Starting at 1,2 make a letter H.  See the test file for shape.
     * 
     * 
     * 
     * 
     * 
     * 
     * 
     */
    public void task()
    {
       // Put code here
    }
}